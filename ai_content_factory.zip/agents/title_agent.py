class TitleAgent:
    def generate_titles(self, text):
        return [
            "震惊！背后真相曝光",
            "很多人都忽略的关键细节",
            "这件事正在悄悄改变一切"
        ]
