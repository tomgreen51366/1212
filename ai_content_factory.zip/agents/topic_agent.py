class TopicAgent:
    def analyze(self, text):
        return {
            "核心话题": text[:20],
            "情绪倾向": "中性/可强化冲突",
            "结构建议": ["开头吸引", "中间冲突", "结尾总结"]
        }
