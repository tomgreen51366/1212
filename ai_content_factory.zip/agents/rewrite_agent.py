import random

class RewriteAgent:
    def generate(self, text):
        variations = []
        for i in range(3):
            variations.append(f"改写版本{i+1}: {text[::-1][:100]}")
        return variations
