# AI Content Factory

一个简单的多Agent内容生产系统示例：

- TopicAgent：分析文章结构
- RewriteAgent：生成改写版本
- TitleAgent：生成标题

运行方式：
python main.py
