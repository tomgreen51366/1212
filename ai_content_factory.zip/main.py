from agents.topic_agent import TopicAgent
from agents.rewrite_agent import RewriteAgent
from agents.title_agent import TitleAgent

def run_pipeline(text):
    topic_agent = TopicAgent()
    rewrite_agent = RewriteAgent()
    title_agent = TitleAgent()

    analysis = topic_agent.analyze(text)
    rewrites = rewrite_agent.generate(text)
    titles = title_agent.generate_titles(text)

    return {
        "analysis": analysis,
        "rewrites": rewrites,
        "titles": titles
    }

if __name__ == "__main__":
    sample_text = "这里输入你的热点文章内容"
    result = run_pipeline(sample_text)

    print("=== 热点分析 ===")
    print(result["analysis"])

    print("\n=== 改写内容 ===")
    for r in result["rewrites"]:
        print("-", r)

    print("\n=== 标题建议 ===")
    for t in result["titles"]:
        print("-", t)
